// carrinho.js

function obterCarrinho() {
  return JSON.parse(localStorage.getItem("carrinho")) || [];
}

function salvarCarrinho(carrinho) {
  localStorage.setItem("carrinho", JSON.stringify(carrinho));
}

function adicionarAoCarrinho(nome, preco) {
  const carrinho = obterCarrinho();
  carrinho.push({ nome, preco });
  salvarCarrinho(carrinho);
  alert(`${nome} adicionado ao carrinho!`);
}

function limparCarrinho() {
  localStorage.removeItem("carrinho");
}

function finalizarCompra() {
  const carrinho = obterCarrinho();
  if (carrinho.length === 0) {
    alert("Seu carrinho está vazio!");
    return;
  }

  const itens = carrinho.map(item => item.nome).join(", ");
  alert(`Compra finalizada com sucesso!\nItens: ${itens}`);
  limparCarrinho();
  if (document.getElementById("listaCarrinho")) atualizarCarrinho();
}

function atualizarCarrinho() {
  const lista = document.getElementById("listaCarrinho");
  const total = document.getElementById("totalCarrinho");

  if (!lista || !total) return;

  const carrinho = obterCarrinho();
  lista.innerHTML = "";
  let totalValor = 0;

  carrinho.forEach(item => {
    const li = document.createElement("li");
    li.textContent = `${item.nome} - R$ ${item.preco.toFixed(2)}`;
    lista.appendChild(li);
    totalValor += item.preco;
  });

  total.textContent = totalValor.toFixed(2);
}
